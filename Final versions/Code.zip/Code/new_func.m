% This function is the right hand side f in the poisson's equation. deltaU = f;
function output = new_func(input_1, input_2)
	%output =sin(input_1);
	%output = coeff;
	%output = 2*((input_1-2.5)^3+(input_2-2.5)^3);
	%output = input_1 + input_2;
    output = 1;
end
